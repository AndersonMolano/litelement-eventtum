import { LitElement, html, css } from "lit-element";

class part3eventtum extends LitElement {
    createRenderRoot() {
        return this;
    }

    render() {
        return html`   
        <style>
          @import "src/css/part3-Eventtum.css";
        </style>

        <div class="contenedor2">
        <div class="texto-content">
            <div class="div1">
                <div class="titulo-list">
                    <h3> Salon Amarrillo</h3>
                </div>
                <div class="content">
                    <h5>Lorem ipsum dolor sit
                        amet, consectetuer adipiscing elit, sed diam
                        nonummy nibh euismod
                        tincidunt ut laoreet </h5>
                </div>
                <div class="botton">
                    <button type="button" class="btn btn-warning fs-5">Mas info</button>
                </div>
            </div>

            <div class="div2">
                <div class="titulo-list">
                    <h3> Salon Amarrillo</h3>
                </div>
                <div class="content">
                    <h5>Lorem ipsum dolor sit
                        amet, consectetuer adipiscing elit, sed diam
                        nonummy nibh euismod
                        tincidunt ut laoreet </h5>
                </div>
                <div class="botton">
                    <button type="button" class="btn btn-warning fs-5">Mas info</button>
                </div>
            </div>

            <div class="div3">
                <div class="titulo-list">
                    <h3> Salon Amarrillo</h3>
                </div>
                <div class="content">
                    <h5>Lorem ipsum dolor sit
                        amet, consectetuer adipiscing elit, sed diam
                        nonummy nibh euismod
                        tincidunt ut laoreet </h5>
                </div>
                <div class="botton">
                    <button type="button" class="btn btn-warning fs-5">Mas info</button>
                </div>
            </div>
        </div>
    </div> `;
    }
};

customElements.define('part3-eventtum', part3eventtum);
