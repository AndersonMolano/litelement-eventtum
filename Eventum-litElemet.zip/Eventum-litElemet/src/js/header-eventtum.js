import { LitElement, html, css } from "lit-element";

class headerEventtum extends LitElement {
    createRenderRoot() {
        return this;
}

    render() {
        return html`   
        <style>
          @import "src/css/headerEventtum.css";
        </style>
     <header>
    <br>
    <div class="cuadrado"></div>
    <div class="cuadrado"></div>
    <div class="cuadrado"></div>

    <img class="puerta" src="src/img/puerta.png" alt="">

</header> `;
    }
};

customElements.define('header-eventtum', headerEventtum);
