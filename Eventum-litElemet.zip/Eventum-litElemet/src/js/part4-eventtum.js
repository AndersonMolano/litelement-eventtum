import { LitElement, html, css } from "lit-element";

class part4eventtum extends LitElement {
    createRenderRoot() {
        return this;
    }

    render() {
        return html`   
        <style>
          @import "src/css/part4-Eventtum.css";
        </style>
        
    <div class="container2">
    <div class="border">
        <img src="src/img/foto2.png" alt="">
    </div>

    <div class="bloque">
        <h1 class="negro">BIENVENIDO A <img src="src/img/Captura de pantalla 2023-08-07 165755.png" class="imagen2">
        </h1>
        <br>
        <h1 class="text2">Lorem ipsum dolor sit amet, consectetuer
            adipiscing elit, sed diam nonummy nibh
            euismod tincidunt ut laoreet dolore
            magna aliquam erat volutpat. Ut wisi
            enim ad minim veniam, quis nostrud</h1>
        <br><br>
        <img class="redes" src="src/img/redes.png" alt="">
    </div>
</div>
<div>
    <h1 class="titulo3">Expertos en eventos</h1>

</div>
<div class="img-final">
    <img src="src/img/foto-final.png" alt="">
</div>
<br><br> `;
    }
};

customElements.define('part4-eventtum', part4eventtum);
