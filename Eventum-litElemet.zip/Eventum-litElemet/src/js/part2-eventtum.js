import { LitElement, html, css } from "lit-element";

class part2eventtum extends LitElement {
    createRenderRoot() {
        return this;
    }

    render() {
        return html`   
        <style>
          @import "src/css/part2-Eventtum.css";
        </style>
       
    <div>
    <h1 class="titulo2">Expertos en eventos</h1>

</div>

<div class="cap">
    <img class="center" src="src/img/cap.png" alt="">
    <img class="center" src="src/img/cap.png" alt="">
    <img class="center" src="src/img/cap.png" alt="">
</div> `;
    }
};

customElements.define('part2-eventtum', part2eventtum);
