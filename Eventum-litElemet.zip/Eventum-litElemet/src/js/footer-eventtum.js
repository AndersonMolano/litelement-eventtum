import { LitElement, html } from "lit-element";

class footerEventtum extends LitElement {
    createRenderRoot() {
        return this;
}

    render() {
        return html`   
        <style>
            @import "src/css/footerEventtum.css";
      </style>
      <footer>
      <div class="fotter">
         <img src="src/img/fotter.png" alt="">
 
      </div>
 </footer>
        `;
    }
};

customElements.define('footer-eventtum', footerEventtum);

