import { LitElement, html, css } from "lit-element";

class part1eventtum extends LitElement {
    createRenderRoot() {
        return this;
}

    render() {
        return html`   
        <style>
          @import "src/css/part1-eventtum.css";
        </style>
        <div class="cuadrado3">
        <img class="logo" src="src/img/Logo.png" alt="">
        <p class="fs-1">Crea, Sueña, Realizalo</p>
        <div class="container">
            <button type="button" class="btn btn-warning fs-5">CONOCENOS</button>
        </div>
    </div>
    <div class="cuadrado2">
        <p class="fs-1s">YA ERES CLIENTE?</p>
        <button type="button" class="btn btn-warning">INGRESA</button>
    </div> `;
    }
};

customElements.define('part1-eventtum', part1eventtum);
